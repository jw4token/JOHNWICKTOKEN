/* eslint-disable @next/next/no-img-element */
import React, { useState } from "react";
import styles from "../styles/Home.module.css";

export default function Navbar() {
  const [activeNav, setactiveNav] = useState<boolean>(false);

  return (
    <div className={styles.navRoot}>
      <a href="#">
        <img
          src="./logooo.png"
          alt="logo"
          width={64}
        />
      </a>
      <div className={styles.noDrop}>
        <a className={styles.navLink} href="#">
          About Us
        </a>
        <a
          className={styles.navLink}
          href="#"
        >
          Roadmap
        </a>
        <a
          className={styles.navLink}
          href="#"
        >
          Tokenomics
        </a>
        <a className={styles.navLink} href="#">
          Whitepaper
        </a>
        <button className={styles.connect} style={{color: "white", background:"#049F82", marginRight:"10px"}}>PRESALE</button>
      </div>
      <div className={styles.dropDown}>
        <div onClick={() => setactiveNav(!activeNav)}>
          {/* <DehazeIcon className={styles.icons} /> */}
        </div>
        <div className={activeNav ? styles.drop : styles.noVis}>
          <a className={styles.navLink} href="#">
            About Us
          </a>
          <a
            className={styles.navLink}
            href="#"
          >
            Roadmap
          </a>
          <a
            className={styles.navLink}
            href="#"
          >
            Tokenomics
          </a>
          <a className={styles.navLink} href="#">
            Whitepaper
          </a>
        </div>
      </div>
    </div>
  );
}
