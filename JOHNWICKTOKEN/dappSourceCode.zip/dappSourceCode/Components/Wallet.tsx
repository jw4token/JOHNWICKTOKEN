import Web3Modal from "web3modal";
import WalletConnectProvider from "@walletconnect/web3-provider";

export let web3Modal: Web3Modal;

export async function init() {
  console.log("initalzing");
  try {
    const providerOptions = {
      walletconnect: {
        package: WalletConnectProvider,
        options: {
          rpc: "https://api.securerpc.com/v1",
          chainId: 1,
        },
      },
    };

    web3Modal = new Web3Modal({
      cacheProvider: false,
      providerOptions,
    });
  } catch (err) {
    console.log(err);
  }
}
