import { Box, MenuItem, TextField } from "@mui/material";
import Image from "next/image";
import React, { useEffect, useState } from "react";
import styles from "../styles/Home.module.css";
import { BuyTokensEth, truncateEthAddress } from "./functions";
import { ConnectButton } from '@rainbow-me/rainbowkit';

const tetxField = {
  "& .MuiInputLabel-root": { color: "none !important" },
  "& .MuiOutlinedInput-root": {
    "& > fieldset": { borderColor: "none !important" },
  },
  "& .MuiOutlinedInput-root:hover": {
    "& > fieldset": { borderColor: "none !important" },
  },
  "& .MuiOutlinedInput-root.Mui-focused": {
    "& > fieldset": {
      borderColor: "none !important",
    },
  },
};

const currencies = [
  {
    value: "USDT",
  },
  {
    value: "ETH",
  },
];

export default function Buy({
  currentRound,
  wallet,
  userAddress,
  presaleReadValues,
  storeWeb3,
  presaleContract,
  buyWithUsdt,
  usdtToEth
}: any) {
  const [usdtRaised, setusdtRaised] = useState<number>(0);
  const [hardCap, sethardCap] = useState<number>(0);
  const [ratePair, setratePair] = useState<string>("0");
  const [tokens, setTokens] = useState("");
  const [currency, setCurrency] = useState("USDT");
  const [EthValue, setEthValue] = useState("");

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setCurrency(event.target.value);
  };

  useEffect(() => {
    if (Object.keys(presaleReadValues).length) {
      const _usdtRaised = Number(presaleReadValues.usdtRaised / 1e18);
      const _hardcap = Number(presaleReadValues.hardCap / 1e18);
      setusdtRaised(_usdtRaised);
      sethardCap(_hardcap);
      setratePair(
        parseFloat((presaleReadValues.usdtRate / 1e18).toString()).toFixed(3)
      );

    }
  }, [presaleReadValues, storeWeb3]);

  const buyTokensETH = async () => {
    if (
      tokens &&
      userAddress &&
      Object.keys(presaleContract).length &&
      !isNaN(Number(tokens))
    ) {
      let _tokens = tokens + "000000000000000000";
      const getEth = await presaleContract.methods
        .getPriceInETH(_tokens, currentRound - 1)
        .call()
        .then(async (val: any) => {
          await BuyTokensEth(
            presaleContract,
            userAddress,
            currentRound - 1,
            "0x0000000000000000000000000000000000000000",
            val,
            _tokens
          );
        });
    } else if (!isNaN(Number(tokens))) {
      alert("Enter correct value");
    }
    setTokens("");
  };

  return (
    <div className={styles.buyRoot}>
      <div className={styles.buttonBox}>
        
        <ConnectButton />
      </div>
      <div className={styles.buyBox}>
        <div style={{ fontSize: "20px", fontWeight: "700" }}>
          PRESALE PHASE {currentRound }
        </div>
        <p style={{ fontSize: "16px", fontWeight: 700, marginBottom: "5px" }}>
          1 JWT = {ratePair} USDT
        </p>

        <progress
          className={styles.progress}
          id="progress"
          value={Math.floor((usdtRaised / hardCap) * 100) || 0}
          max="100"
        />
        <p style={{ fontSize: "16px", fontWeight: 700, marginBottom: "15px" }}>
          USDT RAISED: {usdtRaised.toLocaleString()} /{" "}
          {hardCap.toLocaleString()}
        </p>
        <input
          className={styles.lockInput}
          type="text"
          placeholder="Enter the Token Amount"
          value={tokens !== "" ? tokens : ""}
          onChange={(e) => {
            setTokens(e.target.value);
          }}
        />
        <div className={styles.infoCurrency}>
          <input
            className={styles.lockInput}
            type="text"
            placeholder={currency === "USDT" ? "USDT Amount" : "ETH Amount"}
            value={tokens !== "" && currency === "USDT" ? Number(tokens) * Number(ratePair)  : ( Number(ratePair)) * Number(usdtToEth) * Number(tokens)}
            disabled
            style={{padding:"20px"}}
          />
          <TextField
            sx={tetxField}
            InputProps={{
              style: { color: "white" },
            }}
            id="outlined-select-currency"
            select
            value={currency}
            onChange={handleChange}
          >
            {currencies.map((option: any) => (
              <MenuItem key={option.value} value={option.value}>
                <Box className={styles.tokensList1}>
                  <span className={styles.tokensList}>
                    <img
                      src={option.value === "ETH" ? "/ethereum-eth.svg" : "/tether-usdt-logo-FA55C7F397-seeklogo.com.png"}
                      alt="logo"
                      width={20}
                      height={18}
                    />
                  </span>
                  {option.value}
                </Box>
              </MenuItem>
            ))}
          </TextField>
        </div>
        <div className={styles.buttonBox}>
          <button
            className={styles.Buy}
            onClick={() => {
              buyTokensETH();
              setTokens("");
            }}
          >
            BUY WITH ETH
          </button>
          <button
            className={styles.Buy}
            onClick={() => {
              buyWithUsdt(Number(tokens));
              setTokens("");
            }}
          >
            BUY WITH USDT
          </button>
        </div>
      </div>
    </div>
  );
}
