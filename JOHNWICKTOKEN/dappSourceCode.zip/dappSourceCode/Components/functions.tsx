import Web3 from "web3";
import { Contract } from "web3-eth-contract";

const truncateRegex = /^(0x[a-zA-Z0-9]{5})[a-zA-Z0-9]+([a-zA-Z0-9]{5})$/;

export const truncateEthAddress = (address: string) => {
  const match = address.match(truncateRegex);
  if (!match) return address;
  return `${match[1]}…${match[2]}`;
};

export const getTokenUnlocked = async (
  presale: Contract,
  address: string,
  web3: Web3
) => {
  const result = await presale.methods.getTokensUnlocked(address).call();
  return parseFloat(web3.utils.fromWei(result, "ether")).toFixed(3);
};

export const getSalesInfo = async (presale: Contract, currentRound: number) => {
  const result = await presale.methods.sales(currentRound).call();
  return result;
};

export const getUserInfo = async (
  presale: Contract,
  currentRound: number,
  address: string
) => {
  const result = await presale.methods.users(currentRound, address).call();
  return result;
};

export const getCurrentRound = async (presale: Contract) => {
  const result = await presale.methods.currentRound().call();
  return result;
};

export const BuyTokensEth = async (
  presale: Contract,
  address: string,
  round: number,
  tokenAddres: string,
  ethValue: any,
  amount: any
) => {
  try {
    await presale.methods
      .buyTokens(round,tokenAddres,amount)
      .send({ from: address, value: ethValue });
  } catch (err) {
    console.log(" Error ");
  }
};

export const withdrawTokens = async (
  presale: Contract,
  address: string,
  currentRound: number
) => {
  if (currentRound >= 1) {
    try {
      await presale.methods.withdrawTokens(currentRound-1).send({ from: address });
    } catch (err) {
      console.log("Sale has not been ended yet, pls wait");
    }
  }
};

export const getAllowance = async (
  token: Contract,
  userAddress: string,
  address: string
) => {
  const allowance = await token.methods.allowance(userAddress, address).call();
  return allowance;
};
