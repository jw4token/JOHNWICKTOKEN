import React, { useEffect, useState } from 'react'
import styles from "../styles/Home.module.css";

export default function UserInfo({storeWeb3, presaleReadValues, claim, presaleContract}: any) {

    const [tokensBought, settokensBought] = useState("0")
    const [unlockedTokens, setunlockedTokens] = useState("0")
    const [contributed, setcontributed] = useState("0")

    useEffect(()=>{
        if(storeWeb3 && Object.keys(presaleReadValues).length > 5){
            
            const _bought = (presaleReadValues.totalBought / 1e18);
            settokensBought(parseInt(_bought.toString()).toFixed(0));
            const _unlockedTokens = _bought - (presaleReadValues.totalWithdrawn/ 1e18);
            setunlockedTokens(parseFloat(_unlockedTokens.toString()).toFixed(0))
            const _contributed = parseFloat((presaleReadValues.contribution/1e18).toString()).toFixed(3);
            setcontributed(_contributed);
            
        }
    },[presaleReadValues, storeWeb3])

  return (
    <div className={styles.userRoot}>
        <div className={styles.buyBox}>
            <div className={styles.infoBox}>
                <div className={styles.info}>
                    <span>USDT Contributed</span>
                    <span>{contributed.toLocaleString()} USDT</span>
                </div>
                <div className={styles.info}>
                    <span>Tokens Bought</span>
                    <span>{tokensBought.toLocaleString()} JWT</span>
                </div>
                <div className={styles.info}>
                    <span>Available to Claim</span>
                    <span>{unlockedTokens.toLocaleString()} JWT</span>
                </div>
            </div>
            <button className={styles.Buy} onClick={()=>claim()}>CLAIM</button>
        </div>
    </div>
  )
}
