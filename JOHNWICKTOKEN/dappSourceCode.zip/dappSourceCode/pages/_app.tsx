import { useEffect, useState } from "react";
import "../styles/globals.css";
 import type { AppProps } from "next/app";
 import { QueryClient, QueryClientProvider, useQuery } from "react-query";
import '@rainbow-me/rainbowkit/styles.css';
import {
  getDefaultWallets,
  RainbowKitProvider,
} from '@rainbow-me/rainbowkit';
import { configureChains, createClient, WagmiConfig } from 'wagmi';
import {mainnet } from 'wagmi/chains';
import { jsonRpcProvider } from 'wagmi/providers/jsonRpc';
import { publicProvider } from 'wagmi/providers/public';

const { chains, provider } = configureChains(
  [ mainnet],
  [ jsonRpcProvider({
    rpc: (chain) => ({
      http: `https://rpc.ankr.com/eth`,
    }),
  }),
  ],
);

const { connectors } = getDefaultWallets({
  appName: 'My RainbowKit App',
  chains
});

const wagmiClient = createClient({
  autoConnect: true,
  connectors,
  provider
})
const queryClient = new QueryClient();
export default function App({ Component, pageProps }: AppProps) {
    const [ready, setReady] = useState(false);
  
    useEffect(() => {
      setReady(true);
    }, []);

return (
      <>
        {ready ? (
          <WagmiConfig client={wagmiClient}>
            <RainbowKitProvider chains={chains}>
            <QueryClientProvider client={queryClient}>
              <Component {...pageProps} />
            </QueryClientProvider>
           </RainbowKitProvider>
          </WagmiConfig>
        ) : null}
        
      </>
    );
  }
