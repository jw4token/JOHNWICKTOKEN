import { init, web3Modal } from "../Components/Wallet";
import Web3 from "web3";
import { useEffect, useState } from "react";
import { Contract } from "web3-eth-contract";
import Navbar from "../Components/Navbar";
import Buy from "../Components/Buy";
import UserInfo from "../Components/UserInfo";
import {
  ChainId,
  PresaleAbi,
  PresaleAddress,
  TokenAbi,
  TokenAddress,
  UsdtAbi,
  UsdtAddress,
} from "../Components/helper";
import {
  BuyTokensEth,
  getAllowance,
  getCurrentRound,
  getSalesInfo,
  getTokenUnlocked,
  getUserInfo,
  withdrawTokens,
} from "../Components/functions";
import styles from "../styles/Home.module.css";
import { provider } from "web3-core";

let provider: provider;
let web3: Web3;

const maxApproval = Web3.utils.toBN(
  "115792089237316195423570985008687907853269984665640564039457584007913129639935"
);

const Home = () => {
  const [presaleContract, setPresaleContract] = useState<Contract | null>(null);
  const [userAddress, setUserAddress] = useState<string>("");
  const [usdtContract, setUsdtContract] = useState<Contract | null>(null);
  const [token, setToken] = useState<Contract | null>(null);
  const [storeWeb3, setStoreWeb3] = useState<Web3>(web3);
  const [currentRound, setCurrentRound] = useState<number>(0);
  const [usdtToEth, setusdtToEth] = useState("");

  const [presaleReadValues, setpresaleReadValues] = useState<any>({});

  const wallet = async () => {
    await init();
    await loadBlockdata();
  };

  const loadBlockdata = async () => {
    try {
      provider = await web3Modal.connect();
    } catch (e) {
      console.log("Could not get a wallet connection", e);
      return;
    }
    web3 = new Web3(provider);
    setStoreWeb3(web3);
    await loadBlockdat();
  };

  const loadBlockdat = async () => {
    let _chain: number = 0;
    const Accounts = await web3.eth.getAccounts();
    if (Accounts.length === 0) {
      return;
    }
    await web3.eth.getChainId().then((values) => {
      _chain = values;
    });

    if (_chain === ChainId) {
      setUserAddress(Accounts[0]);
      const _token = new web3.eth.Contract(TokenAbi, TokenAddress);
      setToken(_token);
      const _presale = new web3.eth.Contract(PresaleAbi, PresaleAddress);
      setPresaleContract(_presale);
      const _usdt = new web3.eth.Contract(UsdtAbi, UsdtAddress);
      setUsdtContract(_usdt);
      const _currentRound = await getCurrentRound(_presale);
      setCurrentRound(Number(_currentRound) + 1);
      const getSales = await getSalesInfo(_presale, _currentRound);
      const getUSDTtoETH = await _presale.methods.convertUSDToETH("1000000000000000000").call();
      setusdtToEth(parseFloat((getUSDTtoETH/1e18).toString()).toFixed(6));
      
      const getUsersInfo = await getUserInfo(
        _presale,
        _currentRound,
        Accounts[0]
      );
      setpresaleReadValues({
        ...getSales,
        ...getUsersInfo,
      });
    } else if (window.ethereum.networkVersion !== ChainId) {
      try {
        await window.ethereum.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: web3.utils.toHex(ChainId) }],
        });
      } catch (err: any) {
        // This error code indicates that the chain has not been added to MetaMask
        if (err.code === 4902) {
          await window.ethereum.request({
            method: "wallet_addEthereumChain",
            params: [
              {
                chainName: "Ethreum Mainnet",
                chainId: web3.utils.toHex(ChainId),
                nativeCurrency: { name: "ETH", decimals: 18, symbol: "ETH" },
                rpcUrls: ["https://api.securerpc.com/v1"],
              },
            ],
          });
        }
      }
    } else {
      alert("Connect to ETH Mainnet");
    }
  };

  useEffect(() => {
    if (window.ethereum) {
      window.ethereum.on("accountsChanged", () => {
        window.location.reload();
      });
      window.ethereum.on("networkChanged", () => {
        window.location.reload();
      });
    }
  });

  const buyWithUsdt = async (amount: number) => {
    let _amount = amount + "000000000000000000";
    if (usdtContract && presaleContract && token) {
      const _allowance = await getAllowance(
        usdtContract,
        userAddress,
        PresaleAddress
      );

      if (_allowance >= maxApproval) {
        try {
          await presaleContract.methods
            .buyTokens(currentRound - 1, UsdtAddress, _amount)
            .send({ from: userAddress, value: 0 });
        } catch (err) {
          console.log("tx rejected");
        }
      } else {
        try {
          await usdtContract.methods
            .approve(PresaleAddress, maxApproval)
            .send({ from: userAddress })
            .on("transactionHash", async () => {
              presaleContract.methods
                .buyTokens(currentRound - 1, UsdtAddress, _amount)
                .send({ from: userAddress, value: 0, gasLimit: 100000 });
            });
        } catch (err) {
          console.log("tx rejected");
        }
      }
    }
  };

  const claim = async () => {
    if (
      userAddress &&
      presaleContract &&
      Object.keys(presaleReadValues).length &&
      !presaleReadValues?.isActive
    ) {
      await withdrawTokens(presaleContract, userAddress, currentRound);
    } else if (
      Object.keys(presaleReadValues).length &&
      presaleReadValues?.isActive
    ) {
      alert("Claim feature is not unlocked");
    } else {
      alert("Connect to Wallet");
    }
  };

  useEffect(() => {
    setInterval(async () => {
      if (token && presaleContract) {
        const _currentRound = await getCurrentRound(presaleContract);
        setCurrentRound(Number(_currentRound) + 1);
        const getSales = await getSalesInfo(presaleContract, _currentRound);
        const getUsersInfo = await getUserInfo(
          presaleContract,
          _currentRound,
          userAddress
        );

        setpresaleReadValues({
          ...getSales,
          ...getUsersInfo,
        });
      }
    }, 5000);
  }, [token, presaleContract]);

  useEffect(() => {
    const checkConnection = async () => {
      if (window.ethereum) {
        web3 = new Web3(window.ethereum);
      } else if (window.web3) {
        web3 = new Web3(window.web3.currentProvider);
      }
      if (web3) {
        setStoreWeb3(web3);
        await loadBlockdat();
      }
    };
    checkConnection();
  }, []);

  return (
    <>
      <Navbar />
      <div className={styles.headRoot}>
        <div className={styles.bannerInfo} style={{ padding: "10px" }}>
          <div className={styles.texth1} style={{
                color: "white"}}>JOHN WICK TOKEN</div>
          
          <p style={{ fontSize: "15px",color: "white", }}>
           Lorem ipsum dolor sit amet consectetur adipisicing elit.
          </p>
          <div className={styles.homeButtonBox}>
            <button
              className={styles.connect}
              style={{
                color: "white",
                background: "#049F82",
                marginRight: "10px",
              }}
            >
              WHITEPAPER
            </button>
            <button
              className={styles.connect}
              style={{ color: "white", background: "#049F82" }}
            >
              AUDIT
            </button>
          </div>
        </div>
        <div className={styles.right}>
          <Buy
            currentRound={currentRound}
            wallet={wallet}
            userAddress={userAddress}
            presaleReadValues={presaleReadValues}
            storeWeb3={storeWeb3}
            presaleContract={presaleContract}
            buyWithUsdt={buyWithUsdt}
            usdtToEth={usdtToEth}
          />
          <h2 style={{ color: "white" }}>Your Dashboard</h2>
          <UserInfo
            storeWeb3={storeWeb3}
            presaleReadValues={presaleReadValues}
            claim={claim}
            presaleContract={presaleContract}
          />
        </div>
      </div>
    </>
  );
};

export default Home;
